package ui;

import java.util.List;

import com.dao.Student;
import com.dao.StudentDAO;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	StudentDAO studentDAO=new StudentDAO();
	//	studentDAO.findById("131110305").getAge().toString();
		System.out.println(studentDAO.findById("131110305").getAge().toString());
		
		List<Student> list =studentDAO.findByAge("20");
		for(int i=0;i<list.size();i++){
		//	list.get(i).getName().toString();
			System.out.println(list.get(i).getName().toString());
		}
	*/
	//	StudentDAO studentDAO=new StudentDAO();
	//	studentDAO.findById("131110305").setAge("99");
	//	studentDAO.save(studentDAO.findById("131110305"));
		String s="shabi";
		s=s.concat("erbi");
		System.out.println(s);
		
		
	}
}
